function afficherRecette(type) {
  const recetteDiv = document.getElementById("recette");

  if (type === "cookies") {
    recetteDiv.innerHTML = `
      <h2>🍪 Recette des Cookies</h2>
      <p><strong>Ingrédients :</strong>
      <li>🧂 Ingrédients (pour environ 12 cookies)</li>

<li>250 g de farine</li>

<li>125 g de beurre doux (fondu ou très mou)</li>

<li>100 g de sucre roux</li>

<li>50 g de sucre blanc</li>

<li>1 œuf</li>

<li>1 cuillère à café de levure chimique</li>

<li>1 pincée de sel</li>

<li>1 cuillère à café de vanille (liquide ou en poudre)</li>

<li>150 g de pépites de chocolat 🍫</li>

<strong>👩‍🍳 Préparation</strong>

<li>Préchauffe le four à 180°C (chaleur tournante si possible).</li>

<li>Dans un grand bol, mélange le beurre fondu, le sucre roux, le sucre blanc et la vanille.</li>

<li>Ajoute l’œuf, mélange bien jusqu’à obtenir une texture crémeuse.

<li>Verse la farine, la levure et le sel. Mélange doucement.</li>

<li>Ajoute les pépites de chocolat et mélange encore un peu.</li>

<li>Forme des petites boules avec tes mains (pas trop grosses !) et place-les sur une plaque recouverte de papier cuisson.
➜ Laisse un peu d’espace entre elles, car elles vont s’aplatir à la cuisson.</li>


      
      </p>
      <p><strong>Préparation :</strong> 
     <li> Fais cuire 10 à 12 minutes maximum.
⚠️ Même s’ils semblent encore mous, sors-les du four : ils durciront en refroidissant.</li>
      </p>
    `;
  }

  else if (type === "pizza") {
    recetteDiv.innerHTML = `
      <h2>🍕 Recette de la Pizza</h2>
      <p><strong>Ingrédients :</strong> 
     <lo>
     <li> 250 g de farine</li>

<li>1 cuillère à café de sel</li>

<li>1 cuillère à café de sucre</li>

<li>1 cuillère à soupe d’huile d’olive</li>

<li>1/2 sachet de levure boulangère sèche (ou 10 g de levure fraîche)</li>

<li>150 ml d’eau tiède</li>
      
     </p>
      <p><strong>Pour la sauce tomate :</strong> </p>
      <lo>
      <li>200 g de purée de tomate ou sauce tomate nature</li>

<li>1 cuillère à soupe d’huile d’olive</li>

<li>1 gousse d’ail émincée</li>

<li>1 pincée d’origan ou d’herbes de Provence Sel et poivre</li>
</p>
      <p><strong>Pour la préparation</strong> </p>
      👨‍🍳 
 <strong>1️⃣ Préparer la pâte </strong>
<lo>
<li>Dans un bol, mélange la farine, le sel, et le sucre.</li>

<li>Ajoute la levure dans l’eau tiède (pas chaude, sinon elle meurt) et laisse reposer 5 minutes.

<li>Verse le mélange eau + levure dans la farine, ajoute l’huile d’olive et pétris jusqu’à obtenir une pâte souple.</li>

<li>Couvre le bol avec un torchon et laisse reposer 1h dans un endroit tiède. La pâte doit doubler de volume.</li>

<strong>🍅 2️⃣ Préparer la sauce: </strong>

<li>Fais revenir l’ail dans un peu d’huile d’olive.</li>

<li>Ajoute la sauce tomate, l’origan, le sel et le poivre.</li>

<li>Laisse mijoter 10 minutes à feu doux.</li>

<strong>🧀 3️⃣ Monte ta pizza:</strong>

<li>Étale la pâte sur une surface farinée.</li>

<li>Mets-la sur une plaque de cuisson avec du papier sulfurisé.</li>

<li>Étale la sauce tomate dessus.

<li>Ajoute la mozzarella et les ingrédients de ton choix (ex. jambon, champignons, olives…).</li>

<strong>🔥 4️⃣ Cuisson :</strong>

<li>Préchauffe ton four à 220°C. </li>

<li>Enfourne ta pizza pendant 12 à 15 minutes, jusqu’à ce qu’elle soit dorée et fondante.</li>
</lo>

    `;
  }

  else if (type === "gateau") {
    recetteDiv.innerHTML = `
      <h2>🎂 Recette du Gâteau</h2>
      <p><strong>Ingrédients :</strong> .<p>🧈 (pour 6 à 8 personnes) :
<lo>
<li>200 g de chocolat noir</li>

<li>100 g de beurre</li>

<li>100 g de sucre</li>

<li>4 œufs</li>

<li>50 g de farine</li>

<li>1 pincée de sel</li>
</lo>
</p>
      <p><strong>Préparation :</strong> <lo>
     <li> Mélange tout</li>
    <li> verse dans un moule</li>
    <li>  cuis pendant 25 min à 180°C.</li>
     </lo>
     </p>
     
     
     
     
     
     
     
     
    
    `;
  }
}
// Fonction pour afficher les commentaires sauvegardés
function afficherCommentaires() {
  const liste = document.getElementById("listeCommentaires");
  liste.innerHTML = ""; // vide la liste

  const commentaires = JSON.parse(localStorage.getItem("commentaires")) || [];

  commentaires.forEach(texte => {
    const div = document.createElement("div");
    div.className = "commentaire";
    div.textContent = texte;
    liste.appendChild(div);
  });
}

// Fonction pour ajouter un nouveau commentaire
function ajouterCommentaire() {
  const zoneTexte = document.getElementById("texteCommentaire");
  const texte = zoneTexte.value.trim();

  if (texte === "") {
    alert("Merci d'écrire un commentaire avant d'envoyer !");
    return;
  }

  let commentaires = JSON.parse(localStorage.getItem("commentaires")) || [];
  commentaires.push(texte);
  localStorage.setItem("commentaires", JSON.stringify(commentaires));

  afficherCommentaires();
  zoneTexte.value = "";
}

// Quand la page se charge, on affiche les anciens commentaires
window.onload = afficherCommentaires;


const recettes = [
  {
    titre: "Couscous tunisien",
    description: "Un couscous traditionnel et savoureux.",
    ingredients: "Semoule, légumes, viande, épices",
    preparation: "Cuire la semoule. Préparer la sauce. Mélanger."
  },
  {
    titre: "Ojja",
    description: "Plat tunisien aux œufs et tomates.",
    ingredients: "Œufs, tomates, harissa",
    preparation: "Cuire la sauce puis ajouter les œufs."
  },
  {
    titre: "Salade mechouia",
    description: "Salade grillée tunisienne.",
    ingredients: "Poivrons, tomates, ail",
    preparation: "Griller, mixer, assaisonner."
  },
  {
    titre: "Makroud",
    description: "Pâtisserie tunisienne à la datte.",
    ingredients: "Semoule, dattes, miel",
    preparation: "Façonner, cuire, tremper dans le miel."
  }
];





const maintenant = new Date();
const debut = new Date(maintenant.getFullYear(), 0, 0);
const jour = Math.floor((maintenant - debut) / 86400000);

const recette = recettes[jour % recettes.length];

document.getElementById("titre").textContent = recette.titre;
document.getElementById("description").textContent = recette.description;
document.getElementById("ingredients").textContent = recette.ingredients;
document.getElementById("preparation").textContent = recette.preparation;

document.title = "Recette du jour : " + recette.titre;
